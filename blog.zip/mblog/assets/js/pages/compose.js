$(document).ready(function() {
    $('.summernote').summernote({
	  height: 350
	});
});